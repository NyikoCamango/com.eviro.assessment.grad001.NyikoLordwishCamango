#include "CurrentAccount.h"

CurrentAccount::CurrentAccount()
{
    //ctor
}

CurrentAccount::~CurrentAccount()
{
    //dtor
}

int CurrentAccount::OverdrafLimit(int withdrawalamount)
{
    int maximum=100000;
    int totalAccountBalance=0;
    int AccountBalanc=30000;


    if(withdrawalamount>maximum)
    {
        cout<<"Cannot withdraw funds over R100 000"<<endl;
    }else
    {
       totalAccountBalance=CurrentAccount(withdrawalamount);
        cout<<"You have successfully withdrawn your funds"+totalAccountBalance <<endl;
    }


}

int CurrentAccount::CurrentAccount(int accountbalance)
{

}
