#include "SavingsAccount.h"

SavingsAccount::SavingsAccount()
{
    //ctor
}

SavingsAccount::~SavingsAccount()
{
    //dtor
}

/*This is a function that enables access to a savings account*/
int SavingsAccount:: SavingsAccountWithdrawal(int withdrawalAmount)
{
    int MinAmount=1000;
    SavingsAccountBalance();
    SavingsAccountDeposit();
    if(withdrawalAmount>SavingsAccountBalance() && withdrawalAmount>MinAmount)
    {
        cout<<"You cannot withdraw more than the amount that is within your account"<<endl;
    }else
    {
        cout<<"You have successfully withdrawn your funds"<endl;

    }
}
/*This is a function that enables access to deposit into a savings account*/
int SavingsAccount:: SavingsAccountDeposit()
{
    int MinAmount=1000;
    int Deposit;

    if(Deposit>=MinAmount)
    {
      cout<<"Congratulations, you have succcessfully opened your Savings Account"endl;
    }else
    {
        cout<<"You cannot open a Savings account because you do not meet the minimum requirements"endl;
    }

    int totalAmount=0;
    totalAmount+=Deposit;
    SavingsAccountBalance()=totalAmount;
}

int SavingsAccount::SavingsAccountBalance()
{
}
