
public class Main extends Application{
	public static void main(String args[])
	{
	    launch(args);

	}
}

public void start(Stage stage)throws Exception
{
    ClientLayout pane=new ClientLayout();
    stage.setScene(new Scene(pane,600,600));
    stage.setTitle("Withdrawal account");
    stage.show();
}

