#ifndef CURRENTACCOUNT_H
#define CURRENTACCOUNT_H


class CurrentAccount
{
    public:
        CurrentAccount();
        virtual ~CurrentAccount();
        int OverdrafLimit( int withdrawalamount);
        int CurrentAccountBalance(int accountbalance);


    protected:

    private:
};

#endif // CURRENTACCOUNT_H
