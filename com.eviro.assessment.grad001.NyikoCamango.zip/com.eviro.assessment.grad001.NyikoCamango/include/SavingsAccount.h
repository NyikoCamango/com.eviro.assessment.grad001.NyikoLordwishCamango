#ifndef SAVINGSACCOUNT_H
#define SAVINGSACCOUNT_H


class SavingsAccount
{
    public:
        SavingsAccount();
        virtual ~SavingsAccount();

        /*This is a function that enables access to a savings account*/
        int SavingsAccountWithdrawal(int withdrawalAmount);
       int SavingsAccountDeposit();
       int SavingsAccountBalance();

    protected:

    private:
};

#endif // SAVINGSACCOUNT_H
